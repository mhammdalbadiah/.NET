﻿Public Class frmSalesTax
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtSalesTax.TextChanged

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        txtPurchasePrice.Text = ""
        txtSalesTax.Text = ""
        txtFinalPrice.Text = ""



    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click





        If txtPurchasePrice.Text = "" Then


            MessageBox.Show("Enter purchase price")


        Else

            Dim price As Decimal
            Dim tax As Decimal
            Dim finalPrice As Decimal

            price = Convert.ToDecimal(txtPurchasePrice.Text)

            tax = price * 0.06
            finalPrice = price + tax

            txtSalesTax.Text = tax
            txtFinalPrice.Text = finalPrice

        End If



    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        End
    End Sub

    Private Sub txtPurchasePrice_TextChanged(sender As Object, e As EventArgs) Handles txtPurchasePrice.TextChanged

    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click

        frmlogin.Show()
        Me.Hide()


    End Sub
End Class