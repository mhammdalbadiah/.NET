﻿Public Class frmLogin
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub frmlogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnLogin.Click



        If txtUsername.Text = "admin" And txtPassword.Text = "1234" Then

            frmSalesTax.Show()
            Me.Hide()

        Else

            lblMessage.Text = "Wrong username or password"

        End If



    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnClear.Click


        txtUsername.Text = ""
        txtPassword.Text = ""
        lblMessage.Text = ""


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        End
    End Sub

    Private Sub UserBox_TextChanged(sender As Object, e As EventArgs) Handles txtUsername.TextChanged

    End Sub
End Class
