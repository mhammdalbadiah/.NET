﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSalesTax
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        txtPurchasePrice = New TextBox()
        Label2 = New Label()
        txtSalesTax = New TextBox()
        Label3 = New Label()
        txtFinalPrice = New TextBox()
        btnCalculate = New Button()
        btnReset = New Button()
        btnLogout = New Button()
        btnExit = New Button()
        Label4 = New Label()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(139, 42)
        Label1.Name = "Label1"
        Label1.Size = New Size(181, 32)
        Label1.TabIndex = 0
        Label1.Text = "Purchase Price"
        ' 
        ' txtPurchasePrice
        ' 
        txtPurchasePrice.Location = New Point(397, 51)
        txtPurchasePrice.Name = "txtPurchasePrice"
        txtPurchasePrice.Size = New Size(100, 23)
        txtPurchasePrice.TabIndex = 1
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(139, 110)
        Label2.Name = "Label2"
        Label2.Size = New Size(116, 32)
        Label2.TabIndex = 2
        Label2.Text = "Sales Tax"
        ' 
        ' txtSalesTax
        ' 
        txtSalesTax.Location = New Point(397, 119)
        txtSalesTax.Name = "txtSalesTax"
        txtSalesTax.ReadOnly = True
        txtSalesTax.Size = New Size(100, 23)
        txtSalesTax.TabIndex = 3
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(139, 190)
        Label3.Name = "Label3"
        Label3.Size = New Size(132, 32)
        Label3.TabIndex = 4
        Label3.Text = "Final Price"
        ' 
        ' txtFinalPrice
        ' 
        txtFinalPrice.Location = New Point(397, 199)
        txtFinalPrice.Name = "txtFinalPrice"
        txtFinalPrice.ReadOnly = True
        txtFinalPrice.Size = New Size(100, 23)
        txtFinalPrice.TabIndex = 5
        ' 
        ' btnCalculate
        ' 
        btnCalculate.BackColor = Color.Lime
        btnCalculate.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnCalculate.Location = New Point(547, 340)
        btnCalculate.Name = "btnCalculate"
        btnCalculate.Size = New Size(132, 39)
        btnCalculate.TabIndex = 6
        btnCalculate.Text = "Calculate"
        btnCalculate.UseVisualStyleBackColor = False
        ' 
        ' btnReset
        ' 
        btnReset.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnReset.Location = New Point(387, 340)
        btnReset.Name = "btnReset"
        btnReset.Size = New Size(110, 39)
        btnReset.TabIndex = 7
        btnReset.Text = "Reset"
        btnReset.UseVisualStyleBackColor = True
        ' 
        ' btnLogout
        ' 
        btnLogout.Location = New Point(713, 415)
        btnLogout.Name = "btnLogout"
        btnLogout.Size = New Size(75, 23)
        btnLogout.TabIndex = 8
        btnLogout.Text = "Logout"
        btnLogout.UseVisualStyleBackColor = True
        ' 
        ' btnExit
        ' 
        btnExit.BackColor = Color.Red
        btnExit.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnExit.Location = New Point(208, 340)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(112, 39)
        btnExit.TabIndex = 9
        btnExit.Text = "EXIT"
        btnExit.UseVisualStyleBackColor = False
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Yellow
        Label4.Font = New Font("Segoe UI Black", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(139, 260)
        Label4.Name = "Label4"
        Label4.Size = New Size(237, 32)
        Label4.TabIndex = 10
        Label4.Text = "Sales Tax Rate: 6%"
        ' 
        ' frmSalesTax
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Label4)
        Controls.Add(btnExit)
        Controls.Add(btnLogout)
        Controls.Add(btnReset)
        Controls.Add(btnCalculate)
        Controls.Add(txtFinalPrice)
        Controls.Add(Label3)
        Controls.Add(txtSalesTax)
        Controls.Add(Label2)
        Controls.Add(txtPurchasePrice)
        Controls.Add(Label1)
        Name = "frmSalesTax"
        Text = "Sales Tax Form"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtPurchasePrice As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtSalesTax As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtFinalPrice As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnLogout As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Label4 As Label
End Class
