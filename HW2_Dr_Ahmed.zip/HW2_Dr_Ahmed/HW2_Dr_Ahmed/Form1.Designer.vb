﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        txtUsername = New TextBox()
        txtPassword = New TextBox()
        btnLogin = New Button()
        btnClear = New Button()
        btnExit = New Button()
        lblMessage = New Label()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 32F)
        Label1.Location = New Point(384, 9)
        Label1.Name = "Label1"
        Label1.Size = New Size(211, 59)
        Label1.TabIndex = 0
        Label1.Text = "Welcome "
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(343, 174)
        Label2.Name = "Label2"
        Label2.Size = New Size(128, 32)
        Label2.TabIndex = 1
        Label2.Text = "Username"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(343, 237)
        Label3.Name = "Label3"
        Label3.Size = New Size(122, 32)
        Label3.TabIndex = 2
        Label3.Text = "Password"
        ' 
        ' txtUsername
        ' 
        txtUsername.Location = New Point(497, 183)
        txtUsername.Name = "txtUsername"
        txtUsername.Size = New Size(141, 23)
        txtUsername.TabIndex = 3
        ' 
        ' txtPassword
        ' 
        txtPassword.Location = New Point(497, 246)
        txtPassword.Name = "txtPassword"
        txtPassword.Size = New Size(141, 23)
        txtPassword.TabIndex = 4
        txtPassword.UseSystemPasswordChar = True
        ' 
        ' btnLogin
        ' 
        btnLogin.BackColor = Color.YellowGreen
        btnLogin.Font = New Font("Segoe UI Black", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        btnLogin.ForeColor = Color.Black
        btnLogin.Location = New Point(669, 441)
        btnLogin.Name = "btnLogin"
        btnLogin.Size = New Size(215, 62)
        btnLogin.TabIndex = 5
        btnLogin.Text = " Login"
        btnLogin.UseVisualStyleBackColor = False
        ' 
        ' btnClear
        ' 
        btnClear.Font = New Font("Segoe UI Black", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        btnClear.Location = New Point(395, 441)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(189, 62)
        btnClear.TabIndex = 6
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' btnExit
        ' 
        btnExit.BackColor = Color.Firebrick
        btnExit.Font = New Font("Segoe UI Black", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        btnExit.Location = New Point(127, 441)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(166, 62)
        btnExit.TabIndex = 7
        btnExit.Text = "EXIT"
        btnExit.UseVisualStyleBackColor = False
        ' 
        ' lblMessage
        ' 
        lblMessage.AutoSize = True
        lblMessage.ForeColor = Color.Red
        lblMessage.Location = New Point(460, 593)
        lblMessage.Name = "lblMessage"
        lblMessage.Size = New Size(0, 15)
        lblMessage.TabIndex = 8
        ' 
        ' frmLogin
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(958, 652)
        Controls.Add(lblMessage)
        Controls.Add(btnExit)
        Controls.Add(btnClear)
        Controls.Add(btnLogin)
        Controls.Add(txtPassword)
        Controls.Add(txtUsername)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "frmLogin"
        Text = "Login Form"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents btnLogin As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblMessage As Label

End Class
