﻿Public Class Form1
    Private Sub btnSort_Click(sender As Object, e As EventArgs) Handles btnSort.Click

        Dim input As String
        input = txtNumbers.Text
        Dim parts() As String
        parts = input.Split(","c)
        Dim numbers(parts.Length - 1) As Integer

        For i As Integer = 0 To parts.Length - 1
            numbers(i) = CInt(parts(i))
        Next

        Array.Sort(numbers)

        lblOutput.Text = String.Join(",", numbers)


    End Sub
End Class
