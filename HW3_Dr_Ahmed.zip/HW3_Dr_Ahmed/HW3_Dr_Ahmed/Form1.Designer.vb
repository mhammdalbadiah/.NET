﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        txtNumbers = New TextBox()
        btnSort = New Button()
        lblOutput = New Label()
        SuspendLayout()
        ' 
        ' txtNumbers
        ' 
        txtNumbers.Location = New Point(399, 346)
        txtNumbers.Name = "txtNumbers"
        txtNumbers.Size = New Size(200, 39)
        txtNumbers.TabIndex = 0
        ' 
        ' btnSort
        ' 
        btnSort.Location = New Point(419, 570)
        btnSort.Name = "btnSort"
        btnSort.Size = New Size(150, 46)
        btnSort.TabIndex = 1
        btnSort.Text = "Sort"
        btnSort.UseVisualStyleBackColor = True
        ' 
        ' lblOutput
        ' 
        lblOutput.AutoSize = True
        lblOutput.Location = New Point(443, 450)
        lblOutput.Name = "lblOutput"
        lblOutput.Size = New Size(0, 32)
        lblOutput.TabIndex = 2
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(13F, 32F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1032, 776)
        Controls.Add(lblOutput)
        Controls.Add(btnSort)
        Controls.Add(txtNumbers)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtNumbers As TextBox
    Friend WithEvents btnSort As Button
    Friend WithEvents lblOutput As Label

End Class
