﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Open_L_Door = New Button()
        Close_L_Door = New Button()
        Open_R_Door = New Button()
        Close_R_Door = New Button()
        Label1 = New Label()
        Pic_L_Door = New PictureBox()
        Pic_R_Door = New PictureBox()
        CType(Pic_L_Door, ComponentModel.ISupportInitialize).BeginInit()
        CType(Pic_R_Door, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Open_L_Door
        ' 
        Open_L_Door.Font = New Font("Segoe UI", 20F)
        Open_L_Door.ForeColor = Color.SpringGreen
        Open_L_Door.Location = New Point(12, 552)
        Open_L_Door.Name = "Open_L_Door"
        Open_L_Door.Size = New Size(156, 55)
        Open_L_Door.TabIndex = 0
        Open_L_Door.Text = "Open !"
        Open_L_Door.UseVisualStyleBackColor = True
        ' 
        ' Close_L_Door
        ' 
        Close_L_Door.Font = New Font("Segoe UI", 20F)
        Close_L_Door.ForeColor = Color.Red
        Close_L_Door.Location = New Point(12, 619)
        Close_L_Door.Name = "Close_L_Door"
        Close_L_Door.Size = New Size(156, 55)
        Close_L_Door.TabIndex = 1
        Close_L_Door.Text = "Close !"
        Close_L_Door.UseVisualStyleBackColor = True
        ' 
        ' Open_R_Door
        ' 
        Open_R_Door.Font = New Font("Segoe UI", 20F)
        Open_R_Door.ForeColor = Color.SpringGreen
        Open_R_Door.Location = New Point(1119, 552)
        Open_R_Door.Name = "Open_R_Door"
        Open_R_Door.Size = New Size(156, 55)
        Open_R_Door.TabIndex = 2
        Open_R_Door.Text = "Open !"
        Open_R_Door.UseVisualStyleBackColor = True
        ' 
        ' Close_R_Door
        ' 
        Close_R_Door.Font = New Font("Segoe UI", 20F)
        Close_R_Door.ForeColor = Color.Red
        Close_R_Door.Location = New Point(1119, 619)
        Close_R_Door.Name = "Close_R_Door"
        Close_R_Door.Size = New Size(156, 55)
        Close_R_Door.TabIndex = 3
        Close_R_Door.Text = "Close !"
        Close_R_Door.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 18F)
        Label1.ForeColor = Color.DarkTurquoise
        Label1.Location = New Point(558, 317)
        Label1.Name = "Label1"
        Label1.Size = New Size(194, 32)
        Label1.TabIndex = 4
        Label1.Text = "Pike Any Door !!!"
        ' 
        ' Pic_L_Door
        ' 
        Pic_L_Door.Image = CType(resources.GetObject("Pic_L_Door.Image"), Image)
        Pic_L_Door.Location = New Point(177, 2)
        Pic_L_Door.Name = "Pic_L_Door"
        Pic_L_Door.Size = New Size(375, 679)
        Pic_L_Door.TabIndex = 5
        Pic_L_Door.TabStop = False
        ' 
        ' Pic_R_Door
        ' 
        Pic_R_Door.Image = CType(resources.GetObject("Pic_R_Door.Image"), Image)
        Pic_R_Door.Location = New Point(747, 2)
        Pic_R_Door.Name = "Pic_R_Door"
        Pic_R_Door.Size = New Size(366, 672)
        Pic_R_Door.TabIndex = 6
        Pic_R_Door.TabStop = False
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1287, 844)
        Controls.Add(Pic_R_Door)
        Controls.Add(Pic_L_Door)
        Controls.Add(Label1)
        Controls.Add(Close_R_Door)
        Controls.Add(Open_R_Door)
        Controls.Add(Close_L_Door)
        Controls.Add(Open_L_Door)
        Name = "Form1"
        Text = "Form1"
        CType(Pic_L_Door, ComponentModel.ISupportInitialize).EndInit()
        CType(Pic_R_Door, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Open_L_Door As Button
    Friend WithEvents Close_L_Door As Button
    Friend WithEvents Open_R_Door As Button
    Friend WithEvents Close_R_Door As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Pic_L_Door As PictureBox
    Friend WithEvents Pic_R_Door As PictureBox

End Class
