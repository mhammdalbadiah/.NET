﻿Public Class Form1

    Private Sub Open_L_Door_Click(sender As Object, e As EventArgs) Handles Open_L_Door.Click


        Pic_L_Door.Image = Image.FromFile("C:\Users\mhamm\source\repos\VB_lab2_Door\VB_lab2_Door\door_pic\Open_Door.png")


    End Sub

    Private Sub Close_L_Door_Click(sender As Object, e As EventArgs) Handles Close_L_Door.Click


        Pic_L_Door.Image = Image.FromFile("C:\Users\mhamm\source\repos\VB_lab2_Door\VB_lab2_Door\door_pic\Close_Door.png")


    End Sub

    Private Sub Open_R_Door_Click(sender As Object, e As EventArgs) Handles Open_R_Door.Click


        Pic_R_Door.Image = Image.FromFile("C:\Users\mhamm\source\repos\VB_lab2_Door\VB_lab2_Door\door_pic\Open_Door.png")


    End Sub

    Private Sub Close_R_Door_Click(sender As Object, e As EventArgs) Handles Close_R_Door.Click


        Pic_R_Door.Image = Image.FromFile("C:\Users\mhamm\source\repos\VB_lab2_Door\VB_lab2_Door\door_pic\Close_Door.png")


    End Sub

End Class
