Imports System

Module Program
    Sub Main(args As String())



        Dim Counter As Integer = 0
        Dim Sum As Integer = 0

        Console.WriteLine("The Sum Of These numbers: ")

        For i = 1 To 10
            Console.WriteLine(i)
            Sum += i
        Next

        Console.WriteLine("is : " & Sum)




    End Sub
End Module
