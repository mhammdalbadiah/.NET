Imports System

Module Program
    Sub Main(args As String())

        Dim num1 As Double
        Dim num2 As Double

        Console.WriteLine("Enter the first number :")
        num1 = Console.ReadLine()
        Console.WriteLine("Enter the second number :")
        num2 = Console.ReadLine()
        Console.WriteLine(" num1 + num2 = ")
        Console.WriteLine(num1 + num2)
        Console.WriteLine(" num1 - num2 = ")
        Console.WriteLine(num1 - num2)
        Console.WriteLine(" num1 * num2 = ")
        Console.WriteLine(num1 * num2)
        Console.WriteLine(" num1 / num2 = ")
        Console.WriteLine(num1 / num2)
    End Sub
End Module
